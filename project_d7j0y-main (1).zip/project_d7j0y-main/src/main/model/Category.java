package model;

// Represents categories of blogs
public enum Category {
    TRAVEL, FITNESS, LIFESTYLE, BUSINESS;
}